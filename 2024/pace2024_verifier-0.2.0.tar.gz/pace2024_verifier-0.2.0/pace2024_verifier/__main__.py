from .cli import verify

def main():
    verify()
    