from .cli import verify, test

def verifier():
    verify()

def tester():
    test()
    